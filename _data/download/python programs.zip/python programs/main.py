import math
import dim_lambda  as dim_lambda
import dBlam
import pandas as pd

Set={3,4,5} # the choice of q
results = []
for q in Set:
    for m in range(4, 8): # the choice of m
        for lam in range(2,q): # the choice of lam
            if (q-1) %lam == 0: #  lam  divides q-1
                        h=m//2
                        exponent = math.floor((2 * m - 1) / 3) + 1
                        max_delta = (q ** exponent - 1) // lam + 1
                        for delta in range(2, max_delta+1):
                            k1 = dim_lambda.dimension_C(q, m, lam, delta)
                            if delta == max_delta:
                                dB= None
                            elif  delta %q !=0:
                                    dB= dBlam.d_B(q, m, lam, delta)
                            else:
                                    dB= dBlam.d_B(q, m, lam, delta+1)
                            results.append({
                                            'q': q,
                                            'm': m,
                                            'lambda': lam,
                                             'n':(q**m-1)/lam,
                                            'delta': delta,
                                            'dim': k1,
                                            'Bose distance=dB':dB,

                                        })
df = pd.DataFrame(results)
#chose a path to save the excel file.
desktop_path = '/Users/runzheng/Desktop/BCH/dimension_Bose_results_lam_geq_1_q=3.2.xlsx'
df.to_excel(desktop_path, index=False)

print(f"File saved to desktop: {desktop_path}")