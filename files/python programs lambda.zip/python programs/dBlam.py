import math


def q_adic_expansion(val, q, max_len=128):
    digits = []
    while val > 0:
        digits.append(val % q)
        val //= q
    return digits + [0] * (max_len - len(digits))

def j_delta(q, lambd, delta, h):
    return math.floor(math.log(lambd * delta, q)) - h

def get_r_delta(delta_digits, h, j, m):
    for r in range(-j + m - 2 * h, j + 1):
        if delta_digits[h + r] > 0:
            return r
    return 0

def hat_delta(delta_digits, h, j, r, m, q):
    part1 = sum(delta_digits[ell] * q ** ell for ell in range(h + r, h + j + 1))
    part2 = sum(delta_digits[ell] * q ** (ell - (m - h - r)) for ell in range(m - h - r, h + j + 1))
    return part1 + part2

def left_sum(delta_digits, limit, q):
    return sum(delta_digits[ell] * q ** ell for ell in range(0, limit + 1))

def right_sum(delta_digits, start, end, shift, q):
    return sum(delta_digits[ell] * q ** (ell - shift) for ell in range(start, end + 1))

def d_B(q, m, lambd, delta):
    if delta % q == 0:
        raise ValueError("q must not divide delta")
    h = m // 2
    j = j_delta(q, lambd, delta, h)
    delta_digits = q_adic_expansion(lambd * delta, q)
    r = get_r_delta(delta_digits, h, j, m)
    hat = hat_delta(delta_digits, h, j, r, m, q)
    if (lambd * delta) < q**(m-h):
        return delta
    elif   m % 2 == 1:  # odd m

        left = left_sum(delta_digits, h - j, q)
        right = right_sum(delta_digits, h - r + 1, h + j, h - r + 1, q)

        if left > right:
            return delta
        elif (delta_digits[h - r+1] + lambd - q) != hat % lambd:
            return hat // lambd + 1
        else:
            return hat // lambd + 2

    else:  # even m
        if r != 0:
            left = left_sum(delta_digits, h - j - 1, q)
            right = right_sum(delta_digits, h - r, h + j, h - r, q)
            if left > right:
                return delta
            elif (delta_digits[h - r  ] + lambd - q) != hat % lambd:
                return hat // lambd + 1
            else:
                return hat // lambd + 2
        else:  # r == 0
            left = left_sum(delta_digits, h - j - 1, q)
            right = right_sum(delta_digits, h, h + j, h, q)
            if left >= right:
                return delta
            elif hat % lambd == 0:
                return hat // lambd
            elif delta_digits[h]+lambd-q != hat % lambd:
                return hat // lambd + 1
            else:
                return hat // lambd + 2















