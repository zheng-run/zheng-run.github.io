import math
import dBlam
import pandas as pd

def floor_div(a, b):
    """Integer division with floor rounding"""
    return a // b

def N(a, q):
    """Define N(a) = floor(a-1) - floor((a-1)/q)"""
    return (a - 1) - ((a - 1) // q)

def q_adic_expansion(x, q, length):
    """Calculate q-adic expansion of x, return a list of length, pad with 0 if insufficient"""
    digits = []
    for _ in range(length):
        digits.append(x % q)
        x //= q
    return digits

def sum_q_expansion(digits, q, start, end, shift=0):
    """Calculate ∑_{ℓ=start}^end digits[ℓ] * q^{ℓ - shift}"""
    s = 0
    for i in range(start, end + 1):
        s += digits[i] * (q ** (i - shift))
    return s

def mu(delta_digits, q, h, k, s):
    """Calculate μ(δ)"""
    part1 = sum_q_expansion(delta_digits, q, 0, h - k)
    part2 = sum_q_expansion(delta_digits, q, h - s + 1, h + k, h - s + 1)
    return min(part1, part2)

def mu_tilde(delta_digits, q, h, k, s):
    """Calculate μ̃(δ)"""
    part1 = sum_q_expansion(delta_digits, q, 0, h - k - 1)
    part2 = sum_q_expansion(delta_digits, q, h - s, h + k, h - s)
    return min(part1, part2)

def phi(delta_digits, q, h, k):
    """Calculate φ(δ)"""
    return sum_q_expansion(delta_digits, q, h, h + k, h) - 1

def tau(delta_digits, q, lam, h, k):
    """Calculate τ(δ)"""
    left = sum_q_expansion(delta_digits, q, h, h + k, h)
    right = sum_q_expansion(delta_digits, q, 0, h - 1)
    sum_high = sum(delta_digits[h:h + k + 1])
    if left <= right and delta_digits[h] > 0 and (2 * sum_high) % lam == 0:
        return 1
    else:
        return 0

def T_i_set(delta_digits, q, h, k, s, i):
    """Calculate set 𝒯_i(δ)"""
    lower = q ** (k - i)
    upper = sum_q_expansion(delta_digits, q, h + s, h + k, h + i)
    if upper == math.floor(upper):
        upper= int(upper)-1
    else:
        upper=int(math.floor(upper))
    T = []
    for t in range(lower, upper+1):
        if t % q != 0:
            T.append(t)
    return T

def floor_division_floor(x, lam):
    """Calculate ⌊x/λ⌋"""
    return x // lam

def f_odd(q, lam, m, delta):
    """Calculate f(δ) when m is odd"""
    h = m // 2
    upper_bound = (q ** ( (2 * m - 1) // 3 + 1 ) - 1) // lam + 1
    if delta <= (q ** (h + 1) - 1) // lam + 1:
        return 0

    val = lam * (delta - 1)
    k = 0
    while q ** (h + k) <= val:
        k += 1
    k -= 1

    length = h + k + 1
    delta_digits = q_adic_expansion(val, q, length)

    if k >= m - 2 * h:
        s_candidates = [x for x in range(m - 2 * h - k, k + 1) if delta_digits[h + x] > 0]
        s = min(s_candidates)
        w = sum(delta_digits[ell] * (q ** ell) for ell in range(h + s, h + k + 1))
    else:
        s = None
        w = 0

    mu_val = mu(delta_digits, q, h, k, s) if s is not None else sum_q_expansion(delta_digits, q, 0, h - k)

    term1 = ((q - 1) ** 2) * (k - 1) * (q ** (2 * k - 3)) // lam if k >= 1 else 0
    term2 = floor_division_floor(mu_val + w, lam) - floor_division_floor((mu_val // q) + w, lam)

    sum_double = 0
    for i in range(-k + 1, k + 1):
        T = T_i_set(delta_digits, q, h, k, s if s is not None else 0, i)
        for t in T:
            a = floor_division_floor( ( (t * (q ** (2 * i - 1))) + t ), lam )
            b = floor_division_floor( ( (t * (q ** (2 * i - 2))) + t ), lam )
            sum_double += a - b

    return term1 + term2 + sum_double

def f_even(q, lam, m, delta):
    """Calculate f̃(δ) when m is even"""
    h = m // 2
    upper_bound = (q ** ( (2 * m - 1) // 3 + 1 ) - 1) // lam + 1
    if delta <= (q ** h - 1) // lam + 1:
        return 0

    val = lam * (delta - 1)
    k = 0
    while q ** (h + k) <= val:
        k += 1
    k -= 1

    length = h + k + 1
    delta_digits = q_adic_expansion(val, q, length)

    if k >= m - 2 * h:
        s_candidates = [x for x in range(m - 2 * h - k, k + 1) if delta_digits[h + x] > 0]
        s = min(s_candidates)
        w = sum(delta_digits[ell] * (q ** ell) for ell in range(h + s, h + k + 1))
    else:
        s = None
        w = 0

    mu_t = mu_tilde(delta_digits, q, h, k, s) if s is not None else sum_q_expansion(delta_digits, q, 0, h - k - 1)

    thr1 = (q ** h - 1) // lam + 1
    thr2 = (q ** (h + 1) - 1) // lam + 1

    if thr1 < delta <= thr2:
        sum_part = 0
        for t in range(1, delta_digits[h]):
            sum_part += (floor_division_floor(2 * t, lam) - floor_division_floor(t, lam))
        return floor_division_floor(mu_t + w, lam) - floor_division_floor((mu_t // q) + w, lam) + sum_part

    term1 = (q ** (2 * k - 2)) * (k - 0.5) * ((q - 1) ** 2) / lam
    term2 = (q - 1) / (2 * lam) * (q ** (k - 1) + (1 + (-1) ** lam) / 2)
    term3 = floor_division_floor(mu_t + w, lam) - floor_division_floor((mu_t // q) + w, lam)

    sum_double = 0
    for i in range(-k, k + 1):
        T = T_i_set(delta_digits, q, h, k, s if s is not None else 0, i)
        for t in T:
            a = floor_division_floor( ( (t * (q ** (2 * i))) + t ), lam )
            b = floor_division_floor( ( (t * (q ** (2 * i - 1))) + t ), lam )
            sum_double += a - b

    return int(term1 + term2 + term3 + sum_double)

def g(delta_digits, q, lam, h, k, delta):
    """Calculate g(δ)"""
    thr1 = (q ** h - 1) // lam + 1
    thr2 = (q ** (h + 1) - 1) // lam + 1

    def tau_val():
        return tau(delta_digits, q, lam, h, k)

    if delta <= thr1:
        return 0
    elif thr1 < delta <= thr2:
        part1 = floor_division_floor((delta_digits[h] - 1) * (3 + (-1) ** lam), 2 * lam)
        return part1 + tau_val()
    else:
        phi_val = phi(delta_digits, q, h, k)
        part1 = floor_division_floor(phi_val * (3 + (-1) ** lam), 2 * lam)
        part2 = floor_division_floor((phi_val // q) * (3 + (-1) ** lam), 2 * lam)
        return part1 - part2 + tau_val()

def dimension_C(q, m, lam, delta):
    """Calculate BCH code dimension"""
    if m < 4:
        raise ValueError("m must be greater than or equal to 4")
    h = m // 2
    upper_bound = (q ** ((2 * m - 1) // 3 + 1) - 1) // lam + 1
    if delta < 2 or delta > upper_bound:
        raise ValueError("δ out of defined interval")

    n = (q ** m - 1) // lam
    Nd = N(delta, q)

    val = lam * (delta - 1)
    k = 0
    while q ** (h + k) <= val:
        k += 1
    k -= 1

    length = h + k + 1
    delta_digits = q_adic_expansion(val, q, length)

    if k >= m - 2 * h:
        s_candidates = [x for x in range(m - 2 * h - k, k + 1) if delta_digits[h + x] > 0]
        s = min(s_candidates)
        w = sum(delta_digits[ell] * (q ** ell) for ell in range(h + s, h + k + 1))
    else:
        s = None
        w = 0

    if m % 2 == 1:
        f_val = f_odd(q, lam, m, delta)
        dim = n - m * (Nd - f_val)
    else:
        f_val = f_even(q, lam, m, delta)
        g_val = g(delta_digits, q, lam, h, k, delta)
        dim = n - m * (Nd - f_val) - (m // 2) * g_val

    return dim


